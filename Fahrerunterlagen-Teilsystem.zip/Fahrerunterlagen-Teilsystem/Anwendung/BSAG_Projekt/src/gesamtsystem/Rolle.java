package gesamtsystem;

public enum Rolle {
	Fahrer, 
	Gruppenleiter,
	Mitarbeiter,
	Meldungsersteller,
	Admin;
}
